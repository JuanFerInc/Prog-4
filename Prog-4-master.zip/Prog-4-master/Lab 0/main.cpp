int main(){
	PENE	
}
