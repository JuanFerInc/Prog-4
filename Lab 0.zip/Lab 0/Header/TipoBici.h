#ifndef TIPOBICI_H
#define TIPOBICI_H

enum TipoBici{PASEO, MONTANIA};

#endif